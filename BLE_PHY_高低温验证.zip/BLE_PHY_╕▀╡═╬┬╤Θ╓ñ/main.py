import pandas as pd
import os
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
from datetime import datetime


# 读取原始表格数据
df = pd.read_csv('BLE_PHY_5_0_0_NonRts_TX_RX_test_2023-09-25_17-48-43_813#F5.csv',error_bad_lines=False)


# 筛选出包含关键字的行
keyword = 'TestItem;"Ref. Sensitivity";'
filtered_df = df[df.iloc[:,0].str.contains(keyword)]# 将结果保存为新的 CSV 文件
# 创建新的DataFrame保存提取的数据
new_df = pd.DataFrame(columns=['Ref.Sensitivity_dBm'])
marker_size = 5
text_fontsize = 8
# 提取固定位置的数据并保存到新表格
for index, row in filtered_df.iterrows():
    data = row[0].split(';')[5].strip().replace('"', '')  # 
    # channel = row[0].split(';')[2].strip().replace('"', '')
    # new_df.loc[index] = [channel + " " + data]
    new_df.loc[index] = [data]

# 将每40行数据拆分成多个数据块
chunks = [new_df[i:i+40] for i in range(0, len(new_df), 40)]
# 计算每个数据块之间的间隔
x_interval = 1
# 遍历每个数据块，生成单独的图片并绘制折线图
current_x = 0
x_interval = 5  # 设置为2，表示间隔为2个单位
current_time = datetime.now()
# 使用当前时间创建文件夹名称
folder_name = current_time.strftime("%Y%m%d_%H%M%S") + '_output'
# 创建文件夹
os.makedirs(folder_name)
# 指定文件夹路径
output_folder = folder_name
# 图形文件名列表
output_filenames = ['PHY_1M', 'PHY_2M', 'PHY_s=2', 'PHY_s=8']

for i, chunk in enumerate(chunks):
    # 添加序号列
    chunk.insert(0, '@channel', [f'@CH{j}' for j in range(len(chunk))])
    # 创建新的图形和子图
    fig, ax = plt.subplots()
    x_values = [current_x + j for j in range(len(chunk))]
    y_values = chunk['Ref.Sensitivity_dBm']
    # 绘制折线图并标记数据
    ax.plot(x_values, y_values, marker='o', linestyle='-', markersize=marker_size)
    for x, y in zip(x_values, y_values):
        ax.text(x, y, f'{y}', ha='center', va='bottom', fontsize=text_fontsize)
    # 自动调整y轴范围
    ax.autoscale(enable=True, axis='y')
    # 设置图形标题
    ax.set_title(f'Ref.sensitivity {i+1}')
    # 设置横坐标刻度间隔
    ax.xaxis.set_major_locator(ticker.MultipleLocator(base=x_interval))
    current_x += len(chunk) + x_interval
    # 保存图形为文件
    output_file = os.path.join(output_folder, f'{output_filenames[i]}.png')
    plt.savefig(output_file)
    # 保存CSV文件，并使用相同的文件名
    csv_file = os.path.join(output_folder, f'{output_filenames[i]}.csv')
    chunk.to_csv(csv_file, index=False)
